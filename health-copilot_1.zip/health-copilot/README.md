# Health Copilot

## Run it (5 steps)
1. Install Python 3.10+ and VS Code. Open this folder in VS Code (File > Open Folder).
2. Open the terminal in VS Code (Terminal > New Terminal) and run:
   python -m venv venv
   venv\Scripts\activate          (Windows)   |   source venv/bin/activate   (Mac/Linux)
   pip install -r requirements.txt
3. Copy `.env.example` to a new file named `.env` and paste your Anthropic API key in it.
4. Start the app:
   uvicorn main:app --reload
5. Open http://localhost:8000 and click "Load demo data" to see everything working.

## Files
- main.py          the backend (AI calls, storage, serves the website)
- static/index.html the website
- data.json        created automatically; stores uploaded reports
- .env             your secret key (never share it)

Information only, not medical advice. Use fake data for demos.
