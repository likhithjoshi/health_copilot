import base64, json, os, re
from pathlib import Path

import anthropic
from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

load_dotenv()
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY") or "missing")  # key comes from .env
MODEL = "claude-sonnet-5-5"

BASE = Path(__file__).parent
DATA_FILE = BASE / "data.json"          # simple storage so data survives restarts

app = FastAPI(title="Health Copilot")


# ---------------- storage ----------------
def load_reports() -> list:
    return json.loads(DATA_FILE.read_text("utf-8")) if DATA_FILE.exists() else []

def save_reports(reports: list) -> None:
    DATA_FILE.write_text(json.dumps(reports, indent=2), "utf-8")


# ---------------- prompts ----------------
EXTRACT_PROMPT = """You are a medical document parser. Extract data from this
document and return ONLY valid JSON, no markdown, in this schema:
{
  "document_type": "lab_report | prescription | discharge_summary | other",
  "date": "YYYY-MM-DD or null",
  "lab_values": [
    {"test": str, "value": number, "unit": str,
     "ref_low": number|null, "ref_high": number|null,
     "status": "low | normal | high"}
  ],
  "medications": [
    {"name": str, "dose": str, "frequency": str, "duration": str}
  ],
  "diagnoses": [str]
}
Use null for anything not present. Never guess values."""

EXPLAIN_PROMPT = """You are a health-literacy assistant. Given the structured
data below, write:
1. A 3-4 sentence plain-language summary (simple words)
2. "Things worth noting": abnormal values and what they generally mean
3. "Questions to ask your doctor": 4-5 specific questions
Rules: never diagnose, never recommend starting or stopping medication, always
encourage consulting a doctor for decisions. Be calm, not alarming.

DATA:
"""

CHAT_SYSTEM = """You are a personal health copilot. Answer ONLY using the
user's records below plus general, well-established health information. If the
records don't contain the answer, say so. Never diagnose or advise changing
medication; recommend a clinician for decisions. If the user describes
emergency symptoms (chest pain, trouble breathing, stroke signs, suicidal
thoughts), tell them to seek emergency care immediately.

USER RECORDS:
"""


# ---------------- helpers ----------------
def content_block(file_bytes: bytes, content_type: str) -> dict:
    data = base64.standard_b64encode(file_bytes).decode()
    kind = "document" if content_type == "application/pdf" else "image"
    return {"type": kind, "source": {"type": "base64", "media_type": content_type, "data": data}}

def parse_json(text: str) -> dict:
    """Pull the first JSON object out of the model's reply, even if it adds extra text."""
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        raise ValueError("No JSON found in model reply")
    return json.loads(match.group(0))

def fix_status(data: dict) -> dict:
    """Recompute low/normal/high ourselves so we don't rely only on the AI."""
    for lv in data.get("lab_values") or []:
        lo, hi, v = lv.get("ref_low"), lv.get("ref_high"), lv.get("value")
        if isinstance(v, (int, float)):
            if lo is not None and v < lo: lv["status"] = "low"
            elif hi is not None and v > hi: lv["status"] = "high"
            elif lo is not None or hi is not None: lv["status"] = "normal"
    data.setdefault("lab_values", []); data.setdefault("medications", []); data.setdefault("diagnoses", [])
    return data


# ---------------- API routes ----------------
@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    allowed = {"application/pdf", "image/png", "image/jpeg"}
    if file.content_type not in allowed:
        raise HTTPException(400, "Please upload a PDF, PNG or JPG file.")
    block = content_block(await file.read(), file.content_type)

    try:
        r = client.messages.create(model=MODEL, max_tokens=2500, messages=[
            {"role": "user", "content": [block, {"type": "text", "text": EXTRACT_PROMPT}]}])
        data = fix_status(parse_json(r.content[0].text))

        e = client.messages.create(model=MODEL, max_tokens=1500, messages=[
            {"role": "user", "content": EXPLAIN_PROMPT + json.dumps(data)}])
        explanation = e.content[0].text
    except anthropic.AuthenticationError:
        raise HTTPException(401, "API key is wrong or missing. Check your .env file.")
    except Exception as ex:
        raise HTTPException(500, f"Could not analyze the document: {ex}")

    reports = load_reports()
    report = {"id": len(reports) + 1, "filename": file.filename, "data": data, "explanation": explanation}
    reports.append(report)
    save_reports(reports)
    return report

@app.get("/reports")
def reports():
    return load_reports()

@app.delete("/reports")
def clear_reports():
    save_reports([])
    return {"ok": True}

class ChatIn(BaseModel):
    question: str
    history: list = []

@app.post("/chat")
def chat(body: ChatIn):
    context = json.dumps([r["data"] for r in load_reports()])
    messages = body.history + [{"role": "user", "content": body.question}]
    try:
        r = client.messages.create(model=MODEL, max_tokens=1000,
                                   system=CHAT_SYSTEM + context, messages=messages)
    except anthropic.AuthenticationError:
        raise HTTPException(401, "API key is wrong or missing. Check your .env file.")
    return {"answer": r.content[0].text}

@app.post("/demo")
def load_demo():
    """Fills the app with FAKE reports so you can test and demo without any AI call."""
    def lab(test, value, unit, lo, hi):
        return {"test": test, "value": value, "unit": unit, "ref_low": lo, "ref_high": hi, "status": "normal"}

    rows = [
        ("2025-01-15", 185, 105, 13.8, 5.4),
        ("2025-07-15", 212, 128, 13.1, 5.7),
        ("2026-01-15", 238, 152, 12.4, 6.0),
    ]
    reports = []
    for i, (date, chol, ldl, hb, a1c) in enumerate(rows, 1):
        data = fix_status({
            "document_type": "lab_report", "date": date, "diagnoses": [], "medications": [],
            "lab_values": [
                lab("Total Cholesterol", chol, "mg/dL", 0, 200),
                lab("LDL Cholesterol", ldl, "mg/dL", 0, 100),
                lab("Hemoglobin", hb, "g/dL", 13.0, 17.0),
                lab("HbA1c", a1c, "%", 4.0, 5.6),
            ]})
        reports.append({
            "id": i, "filename": f"demo_lab_report_{date}.pdf", "data": data,
            "explanation": (
                "**Summary**\nThis is sample data. Your cholesterol and blood sugar markers have been "
                "moving upward across reports, and hemoglobin has been drifting down.\n\n"
                "### Things worth noting\n- Total and LDL cholesterol are above the usual limit.\n"
                "- HbA1c is creeping up, which reflects average blood sugar over about 3 months.\n"
                "- Hemoglobin is slightly low in the latest report.\n\n"
                "### Questions to ask your doctor\n1. Are my cholesterol numbers something to treat or just monitor?\n"
                "2. Should I get my blood sugar checked more often?\n3. Could my diet be affecting these results?\n"
                "4. What could explain the lower hemoglobin?\n\n*Not medical advice. Consult a doctor.*")})
    reports.append({
        "id": 4, "filename": "demo_prescription_2026-01-20.jpg",
        "data": {"document_type": "prescription", "date": "2026-01-20", "lab_values": [], "diagnoses": [],
                 "medications": [
                     {"name": "Atorvastatin", "dose": "10 mg", "frequency": "Once daily at night", "duration": "30 days"},
                     {"name": "Metformin", "dose": "500 mg", "frequency": "Twice daily after meals", "duration": "30 days"}]},
        "explanation": "**Summary**\nSample prescription with two medicines. Take them exactly as your doctor advised."})
    save_reports(reports)
    return {"ok": True, "count": len(reports)}


# ---------------- website ----------------
@app.get("/")
def home():
    return FileResponse(BASE / "static" / "index.html")

app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
